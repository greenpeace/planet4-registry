# planet4-content-default
Scripts that control the default content of the default planet4 installation. This repo contains the default content for the first run of Planet-Base. It makes sense to have this content focused on developers, since developers are the ones who will first install and tinker with Planet 4 Github repos.

So, hi devs!

This content will use the WP content types and formats, follow the Planet 4 style guides and otherwise be reflective of the Planet 4 project as a whole.