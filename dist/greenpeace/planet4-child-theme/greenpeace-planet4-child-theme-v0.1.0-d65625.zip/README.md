# Greenpeace Planet 4 Child Theme

Exemplary child theme for the Planet 4 Wordpress project.
The master theme’s code lives at: https://github.com/greenpeace/greenpeace-planet4-master-theme.
